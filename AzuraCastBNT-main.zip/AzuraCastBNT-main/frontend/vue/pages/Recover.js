import initBase from '~/base.js';

import Recover from '~/components/Recover.vue';

export default initBase(Recover);
