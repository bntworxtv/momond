import initBase from '~/base.js';

import WebDJ from '~/components/Public/WebDJ.vue';

export default initBase(WebDJ);
