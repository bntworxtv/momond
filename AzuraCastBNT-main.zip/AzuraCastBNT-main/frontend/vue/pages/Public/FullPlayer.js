import initBase from '~/base.js';

import '~/vendor/fancybox';
import '~/vendor/luxon';

import FullPlayer from '~/components/Public/FullPlayer.vue';

export default initBase(FullPlayer);
