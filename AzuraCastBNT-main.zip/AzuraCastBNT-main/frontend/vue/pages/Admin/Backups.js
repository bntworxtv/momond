import initBase from '~/base.js';

import AdminBackups from '~/components/Admin/Backups.vue';

export default initBase(AdminBackups);
