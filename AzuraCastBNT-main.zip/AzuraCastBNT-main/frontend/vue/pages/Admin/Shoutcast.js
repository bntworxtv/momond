import initBase from '~/base.js';

import AdminShoutcast from '~/components/Admin/Shoutcast.vue';

export default initBase(AdminShoutcast);
