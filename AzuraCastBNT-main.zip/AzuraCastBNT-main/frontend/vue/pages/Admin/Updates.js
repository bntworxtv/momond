import initBase from '~/base.js';

import AdminUpdates from '~/components/Admin/Updates.vue';

export default initBase(AdminUpdates);
