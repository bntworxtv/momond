import initBase from '~/base.js';

import SetupSettings from '~/components/Setup/Settings.vue';

export default initBase(SetupSettings);
