import initBase from '~/base.js';

import BulkMedia from '~/components/Stations/BulkMedia.vue';

export default initBase(BulkMedia);
