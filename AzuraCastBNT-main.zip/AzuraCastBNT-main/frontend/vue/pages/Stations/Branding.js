import initBase from '~/base.js';

import '~/vendor/fancybox';

import StationsBranding from '~/components/Stations/Branding.vue';

export default initBase(StationsBranding);
