import initBase from '~/base.js';

import '~/vendor/chartjs';

import Overview from '~/components/Stations/Reports/Overview.vue';

export default initBase(Overview);
