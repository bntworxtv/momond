import initBase from '~/base.js';

import '~/vendor/luxon';

import Listeners from '~/components/Stations/Reports/Listeners.vue';

export default initBase(Listeners);
