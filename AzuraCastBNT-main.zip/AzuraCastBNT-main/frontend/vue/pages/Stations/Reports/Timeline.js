import initBase from '~/base.js';

import '~/vendor/luxon';

import Timeline from '~/components/Stations/Reports/Timeline.vue';

export default initBase(Timeline);
