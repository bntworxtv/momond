import initBase from '~/base.js';

import '~/vendor/luxon';

import SoundExchange from '~/components/Stations/Reports/SoundExchange.vue';

export default initBase(SoundExchange);
