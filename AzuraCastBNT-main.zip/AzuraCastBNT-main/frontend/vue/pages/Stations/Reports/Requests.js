import initBase from '~/base.js';

import '~/vendor/luxon';

import Requests from '~/components/Stations/Reports/Requests.vue';

export default initBase(Requests);
