export default {
    locale: {
        type: String,
        required: true
    },
    stationTimeZone: {
        type: String,
        required: true
    },
    quotaUrl: {
        type: String,
        required: true
    }
}
