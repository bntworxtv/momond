<?php

return [
    'defaultIncludes' => [
        __DIR__ . '/util/psysh.php',
    ],
];
